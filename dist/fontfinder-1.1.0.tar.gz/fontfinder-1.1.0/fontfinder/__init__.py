"""
FontFinder - A cross-platform font discovery and analysis library.

This module provides functions to discover, filter, and analyze fonts installed
on Windows, macOS, and Linux systems with minimal dependencies.
"""

from .core import (
    get_fonts,
    get_font_files,
    find_fonts,
    check_font_supports_text,
    FontInfo,
    FontType
)

__version__ = "1.1.0"
__author__ = "FontFinder Team"
__email__ = "contact@fontfinder.dev"

__all__ = [
    "get_fonts",
    "get_font_files", 
    "find_fonts",
    "check_font_supports_text",
    "FontInfo",
    "FontType"
]